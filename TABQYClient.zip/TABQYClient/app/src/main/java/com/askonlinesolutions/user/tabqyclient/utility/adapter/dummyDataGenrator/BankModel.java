package com.askonlinesolutions.user.tabqyclient.utility.adapter.dummyDataGenrator;


public class BankModel {

    /**
     * bankId : 1
     * bankName : Al Ahli Bank of Kuwait - ABK
     */

    private int bankId;
    private String bankName;

    public int getBankId() {
        return bankId;
    }

    public void setBankId(int bankId) {
        this.bankId = bankId;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }
}
