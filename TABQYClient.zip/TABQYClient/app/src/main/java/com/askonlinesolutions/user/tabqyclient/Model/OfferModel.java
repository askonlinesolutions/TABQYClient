package com.askonlinesolutions.user.tabqyclient.Model;

public class OfferModel
{
    String name;

    public OfferModel(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
